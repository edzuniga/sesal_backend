# 🔄 Diagrama de Flujo de Configuración

## 📊 Flujo de Carga de Configuración de Base de Datos

```
┌─────────────────────────────────────────────────────────────┐
│                    INICIO DE APLICACIÓN                      │
│                     (src/server.ts)                          │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│         prepararConfiguracion()                              │
│   configuracionBDServicio.cargarConfiguracionPersistida()   │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
                ┌────────────────┐
                │ NODE_ENV === ? │
                └────────┬───────┘
                         │
         ┌───────────────┴───────────────┐
         │                               │
         ▼                               ▼
┌─────────────────┐            ┌─────────────────┐
│  'production'   │            │  'development'  │
└────────┬────────┘            └────────┬────────┘
         │                               │
         ▼                               ▼
┌─────────────────────────────┐  ┌──────────────────────────┐
│ 🔒 MODO PRODUCCIÓN          │  │ 🔓 MODO DESARROLLO       │
│                             │  │                          │
│ 1. IGNORA archivo           │  │ 1. Lee archivo           │
│    .bi-sesal/               │  │    .bi-sesal/            │
│                             │  │    database-config.json  │
│ 2. USA SOLO variables       │  │                          │
│    de ecosystem.config.js:  │  │ 2. Si existe:            │
│    - MYSQL_HOST             │  │    → Usa config archivo  │
│    - MYSQL_PORT             │  │                          │
│    - MYSQL_USER             │  │ 3. Si NO existe:         │
│    - MYSQL_PASSWORD         │  │    → Usa .env            │
│    - MYSQL_DATABASE         │  │                          │
└──────────────┬──────────────┘  └──────────┬───────────────┘
               │                            │
               └──────────┬─────────────────┘
                          │
                          ▼
         ┌────────────────────────────────┐
         │   crearNuevoPool()             │
         │   (src/base_datos/pool.ts)     │
         └────────────────┬───────────────┘
                          │
                          ▼
         ┌────────────────────────────────┐
         │   mysql.createPool({           │
         │     host: config.host,         │
         │     port: config.port,         │
         │     user: config.username,     │
         │     password: config.password, │
         │     database: config.database  │
         │   })                           │
         └────────────────┬───────────────┘
                          │
                          ▼
         ┌────────────────────────────────┐
         │   ✅ POOL INICIALIZADO         │
         │   Aplicación lista             │
         └────────────────────────────────┘
```

## 🎯 Prioridad de Configuración

### En Producción (NODE_ENV=production)

```
┌─────────────────────────────────────────┐
│  PRIORIDAD 1 (ÚNICA):                   │
│  ecosystem.config.js                    │
│  ✅ Siempre se usa                      │
│                                         │
│  IGNORADO:                              │
│  .bi-sesal/database-config.json         │
│  ❌ Nunca se lee                        │
└─────────────────────────────────────────┘
```

### En Desarrollo (NODE_ENV=development)

```
┌─────────────────────────────────────────┐
│  PRIORIDAD 1:                           │
│  .bi-sesal/database-config.json         │
│  ✅ Si existe, se usa                   │
│                                         │
│  PRIORIDAD 2 (fallback):                │
│  .env                                   │
│  ✅ Si no existe archivo, se usa .env   │
└─────────────────────────────────────────┘
```

## 🔀 Flujo de Solicitud HTTP

```
┌──────────────┐
│   Cliente    │
│  (Frontend)  │
└──────┬───────┘
       │ HTTP Request
       │ Origin: http://172.16.36.59
       ▼
┌──────────────────────────────────────┐
│  Middleware: CORS                    │
│  (src/aplicacion.ts)                 │
│                                      │
│  1. Lee CORS_ORIGINS del env         │
│  2. Valida origin                    │
│  3. Si válido: continúa              │
│     Si inválido: Error 403           │
└──────────────┬───────────────────────┘
               │ ✅ CORS OK
               ▼
┌──────────────────────────────────────┐
│  Middleware: Rate Limit              │
│  (300 req/min por IP)                │
└──────────────┬───────────────────────┘
               │ ✅ Rate OK
               ▼
┌──────────────────────────────────────┐
│  Rutas: /api/*                       │
│  (src/rutas/)                        │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Controlador                         │
│  (src/controladores/)                │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  Servicio                            │
│  (src/servicios/)                    │
└──────────────┬───────────────────────┘
               │ Query SQL
               ▼
┌──────────────────────────────────────┐
│  Pool de Conexiones                  │
│  (src/base_datos/pool.ts)            │
│                                      │
│  Configuración según NODE_ENV        │
└──────────────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────┐
│  MySQL Server                        │
│  172.16.34.68:3306                   │
│  Database: sesal_historico           │
│  User: root                          │
└──────────────┬───────────────────────┘
               │ Resultado
               ▼
┌──────────────────────────────────────┐
│  Respuesta JSON al Cliente           │
└──────────────────────────────────────┘
```

## 🏗️ Arquitectura de Servidores

```
┌─────────────────────────────────────────────────────────────┐
│                     ARQUITECTURA ACTUAL                      │
└─────────────────────────────────────────────────────────────┘

┌──────────────────┐         ┌──────────────────┐         ┌──────────────────┐
│   Servidor 1     │         │   Servidor 2     │         │   Servidor 3     │
│   FRONTEND       │         │   BACKEND        │         │   BASE DE DATOS  │
│                  │         │                  │         │                  │
│  IP: 172.16.36.59│────────▶│  IP: 172.16.36.58│────────▶│  IP: 172.16.34.68│
│                  │  HTTP   │                  │  MySQL  │                  │
│  Vue.js          │  Req    │  Node.js/Express │  Query  │  MySQL 8.0       │
│  Puerto: 80/443  │         │  Puerto: 4000    │         │  Puerto: 3306    │
│                  │         │  PM2 (cluster)   │         │                  │
│                  │         │  2 instancias    │         │  sesal_historico │
└──────────────────┘         └──────────────────┘         └──────────────────┘
         │                            │                            │
         │                            │                            │
         └────────────────────────────┴────────────────────────────┘
                              Red Interna
                           172.16.x.x/24
```

## 🔧 Variables de Entorno por Servidor

### Servidor Backend (172.16.36.58)

```env
# ecosystem.config.js
NODE_ENV=production
PORT=4000

# Conexión a BD (Servidor 3)
MYSQL_HOST=172.16.34.68
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=Animalit0..9
MYSQL_DATABASE=sesal_historico

# CORS (Servidor 1)
CORS_ORIGINS=http://172.16.36.59

# Pool de conexiones
MYSQL_CONNECTION_LIMIT=50
MYSQL_QUEUE_LIMIT=200
MYSQL_CONNECT_TIMEOUT=20000
MYSQL_QUERY_TIMEOUT=300000
```

## 🔍 Puntos de Verificación

```
┌─────────────────────────────────────────────────────────────┐
│              CHECKLIST DE VERIFICACIÓN                       │
└─────────────────────────────────────────────────────────────┘

1. ✅ Variables de Entorno
   └─ pm2 env 0 | grep MYSQL
      Debe mostrar: MYSQL_USER=root

2. ✅ Archivo Persistido
   └─ ls -la .bi-sesal/
      Debe mostrar: No such file or directory

3. ✅ Conexión a BD
   └─ curl http://localhost:4000/api/health/db
      Debe responder: {"connected":true}

4. ✅ Logs de PM2
   └─ pm2 logs bisesal-backend | grep "DB CONFIG"
      Debe mostrar: user: root

5. ✅ CORS
   └─ Desde frontend, hacer request
      No debe haber errores de CORS

6. ✅ Modo Producción
   └─ pm2 logs bisesal-backend | grep "Modo producción"
      Debe mostrar: "🔒 Modo producción: usando solo variables de entorno"
```

## 🚨 Flujo de Error Común (RESUELTO)

### Antes (con error):

```
PM2 start
    │
    ▼
Lee .bi-sesal/database-config.json
    │
    ▼
Usuario: wsuario1 ❌
Host: 172.16.36.58 ❌
    │
    ▼
Intenta conectar a MySQL
    │
    ▼
❌ Access denied for user 'wsuario1'@'172.16.36.58'
```

### Ahora (funcionando):

```
PM2 start
    │
    ▼
NODE_ENV=production detectado
    │
    ▼
IGNORA .bi-sesal/database-config.json
    │
    ▼
Lee ecosystem.config.js
    │
    ▼
Usuario: root ✅
Host: 172.16.34.68 ✅
Puerto: 3306 ✅
    │
    ▼
Conecta a MySQL
    │
    ▼
✅ Conexión exitosa
```

## 📝 Notas Técnicas

- **Pool de Conexiones**: 50 conexiones simultáneas en producción
- **Timeout de Queries**: 5 minutos (300,000 ms)
- **Rate Limiting**: 300 requests por minuto por IP
- **Charset**: utf8mb4 (soporte completo de Unicode)
- **Keep-Alive**: Habilitado con delay de 10 segundos
- **Cluster Mode**: PM2 en modo cluster (múltiples instancias)

---

**Última actualización**: Diciembre 2025
